import java.util.*;

/**
 * Created by Christina on 2/2/16.
 */
public class GraphValidTree {


    //O(n), O(the width of the tree)
    public boolean validTree(int n, int[][] edges) {
        Map<Integer, Node> nodeMap = new HashMap<>();
        for (int i = 0; i < edges.length; i++) {
            int val_1 = edges[i][0], val_2 = edges[i][1];
            if (!nodeMap.containsKey(val_1)) nodeMap.put(val_1, new Node(val_1));
            if (!nodeMap.containsKey(val_2)) nodeMap.put(val_2, new Node(val_2));
            nodeMap.get(val_1).next.add(nodeMap.get(val_2));
            nodeMap.get(val_2).next.add(nodeMap.get(val_1));
        }

        if (nodeMap.size() != n) return false;

        boolean[] visited = new boolean[n];
        Node[] last = new Node[n];


        //bfs
        for (int i = 0; i < n; i++) {
            if (!visited[i] && i != 0) return false;
            if (visited[i]) continue;
            Queue<Node> que = new LinkedList<>();
            que.add(nodeMap.get(i));
            while (!que.isEmpty()) {
                int size = que.size();
                while (size -- != 0) {
                    Node temp = que.poll();
                    visited[temp.val] = true;
                    for (Node next:temp.next) {
                        last[next.val] = temp;
                        if (next == last[temp.val]) continue;
                        if (visited[next.val]) {
                            return false;
                        }
                        que.add(next);
                    }
                }
            }
        }
        return true;
    }
    class Node {
        int val;
        List<Node> next;
        Node(int val) {
            this.val = val;
            next = new ArrayList<>();
        }
    }

    public static void main(String[] arg) {
        GraphValidTree a = new GraphValidTree();

        System.out.println(a.validTree(4, new int[][]{
                {0, 1}, {2, 3}
        }));

        System.out.println(a.validTree(5, new int[][]{
                {0, 1}, {0, 2}, {0, 3}, {1, 4}
        }));



        System.out.println(a.validTree(5, new int[][]{
                {0, 1}, {1, 2}, {2, 3}, {1, 3}, {1, 4}
        }));






    }
}
