/**
 * Created by Christina on 2/20/16.
 */
public class Point {
    int x, y;

    Point(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
