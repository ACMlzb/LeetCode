import java.util.List;

/**
 * Created by Christina on 3/1/16.
 */
public class NestedToLinkedLisk {

    public ListNode nestedToLinkedList(List<List<Integer>> list) {
        return new ListNode(1);
    }


}
