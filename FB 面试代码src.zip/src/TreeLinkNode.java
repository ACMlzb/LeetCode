/**
 * Created by Christina on 1/16/16.
 */
public class TreeLinkNode {
    int val;
    TreeLinkNode left, right, next;
    TreeLinkNode(int x) { val = x; }
    public String toString() {
        return val + "";
    }
}
