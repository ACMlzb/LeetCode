/**
 * Created by Christina on 2/29/16.
 */
public class PrintLongestPathOfTree {
    /**
     * 维护一个最长的路径，搜索的时候搜到leaf节点，如果比当前维护的最长路径长，就更新一下最长路径，最后返回。
     * */
}
