///**
// * Created by Christina on 2/29/16.
// */
//public class getAllSumCombinations {
//    /**
//     * 给一个正数n，打印出所有相加的组合
//     例如10可以打印出
//     1+1+1+...1
//     1+2+1+...1
//     ..
//     9+1
//     10
//
//     Combination Sum???
//     * */
//}
